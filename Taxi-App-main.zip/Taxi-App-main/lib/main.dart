import 'package:app_taxi/src/resource/app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}




